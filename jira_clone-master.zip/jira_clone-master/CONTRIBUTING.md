I will not be accepting PR's on this repository. Feel free to fork and maintain your own version.
